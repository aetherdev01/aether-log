package com.aether.lv

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch
import com.aether.lv.ads.AdBlockManager
import com.aether.lv.ads.AdsManager
import com.aether.lv.ads.RewardedNoAdsManager
import com.aether.lv.data.preferences.ThemePreferences
import com.aether.lv.permission.PermissionManager
import com.aether.lv.permission.PermissionRationaleDialog
import com.aether.lv.ui.LogLogApp
import com.aether.lv.ui.theme.LogLogTheme

class MainActivity : ComponentActivity() {

    private var externalFileUri: Uri? = null

    private var showPermissionDialog     by mutableStateOf(false)
    private var showManageStorageDialog  by mutableStateOf(false)

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ -> }


private val blockAdBackPressCallback = object : OnBackPressedCallback(false) {
    override fun handleOnBackPressed() {
        // Sengaja dikosongkan: saat iklan tampil, back gesture harus diabaikan.
    }
}

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        externalFileUri = when (intent?.action) {
            Intent.ACTION_VIEW -> intent.data?.also { uri -> persistUriPermission(uri, intent) }
            else               -> null
        }

        requestStoragePermissionIfNeeded()

        onBackPressedDispatcher.addCallback(this, blockAdBackPressCallback)
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                AdsManager.isAdShowing.collect { isShowing ->
                    blockAdBackPressCallback.isEnabled = isShowing
                }
            }
        }

        // SDK init + preload sudah dilakukan di LogLogApplication.onCreate().
        // Tidak perlu init ulang di sini — AdsManager.initialize() adalah no-op jika sudah init.
        // AdBlock detection mulai setelah grace period.
        AdBlockManager.startDetection(this)

        val themePrefs = ThemePreferences(this)

        setContent {
            val isDark    by themePrefs.isDarkMode.collectAsState(initial = false)
            val isDynamic by themePrefs.isDynamicColor.collectAsState(initial = true)

            LogLogTheme(darkTheme = isDark, dynamicColor = isDynamic) {
                LogLogApp(
                    externalFileUri     = externalFileUri,
                    themePrefs          = themePrefs,
                    onRequestPermission = { requestStoragePermissionIfNeeded(force = true) },
                    onShowInterstitial  = { afterAction ->
                        showInterstitialAd(
                            onComplete = afterAction,
                            onFailed   = { afterAction() }
                        )
                    },
                    onShowRewarded      = { showRewardedAd() }
                )

                if (showPermissionDialog) {
                    PermissionRationaleDialog(
                        showManageStorage   = false,
                        onRequestPermission = {
                            showPermissionDialog = false
                            requestPermissionLauncher.launch(
                                PermissionManager.requiredPermissions().toTypedArray()
                            )
                        },
                        onOpenSettings = {
                            showPermissionDialog = false
                            PermissionManager.appSettingsIntent(this).also { startActivity(it) }
                        },
                        onDismiss = { showPermissionDialog = false }
                    )
                }

                if (showManageStorageDialog) {
                    PermissionRationaleDialog(
                        showManageStorage   = true,
                        onRequestPermission = {},
                        onOpenSettings = {
                            showManageStorageDialog = false
                            PermissionManager.manageStorageSettingsIntent(this)
                                ?.also { startActivity(it) }
                        },
                        onDismiss = { showManageStorageDialog = false }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_VIEW) {
            externalFileUri = intent.data?.also { uri -> persistUriPermission(uri, intent) }
        }
    }

    override fun onResume() {
        super.onResume()
        if (PermissionManager.hasStoragePermission(this) ||
            PermissionManager.canReadArbitraryFiles(this)) {
            showPermissionDialog    = false
            showManageStorageDialog = false
        }
    }

    /**
     * Tampilkan interstitial.
     * Reload berikutnya sudah ditangani di dalam AdsManager.showInterstitial()
     * (setelah onComplete/onFailure) — tidak perlu reload manual di sini.
     */
    fun showInterstitialAd(
        onComplete: () -> Unit = {},
        onFailed  : (String) -> Unit = {}
    ) {
        if (RewardedNoAdsManager.isNoAdsActive()) {
            onComplete()
            return
        }

        AdsManager.showInterstitial(
            activity   = this,
            onComplete = onComplete,
            onFailed   = onFailed
        )
    }

    /**
     * Tampilkan rewarded ad.
     * onRewarded dipanggil hanya jika user menonton sampai selesai.
     */
    fun showRewardedAd(
        onRewarded : () -> Unit = {},
        onComplete : () -> Unit = {},
        onFailed   : (String) -> Unit = {}
    ) {
        if (!RewardedNoAdsManager.canWatchRewarded()) {
            val message = "Limit rewarded harian sudah habis (2x/hari)"
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            onFailed(message)
            return
        }

        AdsManager.showRewarded(
            activity   = this,
            onRewarded = {
                if (RewardedNoAdsManager.grant30Minutes()) {
                    onRewarded()
                } else {
                    val message = "Limit rewarded harian sudah habis (2x/hari)"
                    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                    onFailed(message)
                }
            },
            onComplete = onComplete,
            onFailed   = { message ->
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                onFailed(message)
            }
        )
    }

    private fun persistUriPermission(uri: Uri, intent: Intent) {
        val flags = intent.flags and (
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
            Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        try {
            contentResolver.takePersistableUriPermission(uri, flags)
        } catch (_: SecurityException) { }
    }

    fun requestStoragePermissionIfNeeded(force: Boolean = false) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
            android.os.Environment.isExternalStorageManager()) return

        val perms = PermissionManager.requiredPermissions()

        if (perms.isEmpty()) {
            if (force) showManageStorageDialog = true
            return
        }

        val allGranted = perms.all { perm ->
            androidx.core.content.ContextCompat.checkSelfPermission(this, perm) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        if (allGranted && !force) return

        val shouldShowRationale = perms.any { shouldShowRequestPermissionRationale(it) }

        when {
            force && shouldShowRationale -> showPermissionDialog = true
            force && !shouldShowRationale && !allGranted -> showManageStorageDialog = true
            else -> requestPermissionLauncher.launch(perms.toTypedArray())
        }
    }
}
