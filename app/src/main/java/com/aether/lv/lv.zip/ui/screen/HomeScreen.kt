package com.aether.lv.ui.screen

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aether.lv.ads.AdsManager
import com.aether.lv.data.model.RecentFile
import com.aether.lv.update.UpdateDialog
import com.aether.lv.util.FileTypeUtil
import com.aether.lv.util.FormatUtil
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpenFile         : (Uri) -> Unit,
    onSettings         : () -> Unit,
    onAbout            : () -> Unit,
    onShowInterstitial : (() -> Unit) -> Unit = { it() },
    vm                 : HomeViewModel = viewModel()
) {
    val recentFiles       by vm.recentFiles.collectAsStateWithLifecycle()
    val updateState       by vm.updateVm.state.collectAsStateWithLifecycle()
    var showClearDialog   by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope             = rememberCoroutineScope()
    var fileOpenCount     by remember { mutableStateOf(0) }

    val handleOpenFile: (Uri) -> Unit = { uri ->
        fileOpenCount++
        if (fileOpenCount % 2 == 0 && AdsManager.interstitialReady.value) {
            onShowInterstitial { onOpenFile(uri) }
        } else {
            onOpenFile(uri)
        }
    }

    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { handleOpenFile(it) } }

    if (updateState.showDialog) {
        UpdateDialog(
            state      = updateState,
            onDismiss  = { vm.updateVm.dismissDialog() },
            onDownload = { vm.updateVm.startDownload() },
            onInstall  = { vm.updateVm.install() },
            onRetry    = { vm.updateVm.retryDownload() }
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape    = RoundedCornerShape(10.dp),
                                color    = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Outlined.Article, null,
                                        modifier = Modifier.size(18.dp),
                                        tint     = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(
                                "LogLog",
                                style      = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    },
                    actions = {
                        AnimatedVisibility(
                            visible = updateState.updateInfo?.isNewVersion == true,
                            enter   = scaleIn() + fadeIn(),
                            exit    = scaleOut() + fadeOut()
                        ) {
                            BadgedBox(badge = {
                                Badge(containerColor = MaterialTheme.colorScheme.error)
                            }) {
                                IconButton(onClick = { vm.updateVm.showUpdateDialog() }) {
                                    Icon(Icons.Outlined.SystemUpdate, "Update tersedia")
                                }
                            }
                        }
                        IconButton(onClick = onAbout) {
                            Icon(Icons.Outlined.Info, "Tentang")
                        }
                        IconButton(onClick = onSettings) {
                            Icon(Icons.Outlined.Settings, "Pengaturan")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
                if (recentFiles.isNotEmpty()) {
                    HorizontalDivider(thickness = 0.5.dp)
                }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick        = { filePicker.launch(arrayOf("*/*")) },
                icon           = { Icon(Icons.Rounded.FolderOpen, null) },
                text           = { Text("Buka File") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor   = MaterialTheme.colorScheme.onPrimary
            )
        }
    ) { innerPadding ->
        AnimatedContent(
            targetState    = recentFiles.isEmpty(),
            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) },
            modifier       = Modifier.fillMaxSize().padding(innerPadding)
        ) { isEmpty ->
            if (isEmpty) {
                EmptyState(
                    modifier   = Modifier.fillMaxSize(),
                    onPickFile = { filePicker.launch(arrayOf("*/*")) }
                )
            } else {
                LazyColumn(
                    modifier            = Modifier.fillMaxSize(),
                    contentPadding      = PaddingValues(bottom = 96.dp),
                ) {
                    // ── Header ───────────────────────────────────────────────
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment     = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment     = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    Icons.Outlined.History, null,
                                    modifier = Modifier.size(15.dp),
                                    tint     = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    "Riwayat",
                                    style      = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.SemiBold,
                                    color      = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer
                                ) {
                                    Text(
                                        "${recentFiles.size}",
                                        style    = MaterialTheme.typography.labelSmall,
                                        color    = MaterialTheme.colorScheme.onSecondaryContainer,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            TextButton(
                                onClick        = { showClearDialog = true },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                            ) {
                                Icon(Icons.Outlined.DeleteSweep, null, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Hapus Semua", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }

                    // ── File list — satu Surface besar berisi semua item ──────
                    item {
                        Surface(
                            modifier       = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            shape          = RoundedCornerShape(16.dp),
                            color          = MaterialTheme.colorScheme.surfaceContainerLow,
                            tonalElevation = 0.dp,
                        ) {
                            Column {
                                recentFiles.forEachIndexed { index, file ->
                                    RecentFileRow(
                                        file     = file,
                                        onClick  = {
                                            if (file.isPersisted) {
                                                handleOpenFile(Uri.parse(file.path))
                                            } else {
                                                scope.launch {
                                                    snackbarHostState.showSnackbar(
                                                        message  = "Buka lagi dari file manager.",
                                                        duration = SnackbarDuration.Short
                                                    )
                                                }
                                            }
                                        },
                                        onDelete = { vm.removeRecent(file.path) }
                                    )
                                    if (index < recentFiles.lastIndex) {
                                        HorizontalDivider(
                                            modifier  = Modifier.padding(start = 64.dp),
                                            thickness = 0.5.dp,
                                            color     = MaterialTheme.colorScheme.outlineVariant
                                                .copy(alpha = 0.5f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            icon             = { Icon(Icons.Outlined.DeleteForever, null) },
            title            = { Text("Hapus Semua Riwayat?") },
            text             = { Text("Semua riwayat file yang pernah dibuka akan dihapus.") },
            confirmButton    = {
                TextButton(onClick = { vm.clearHistory(); showClearDialog = false }) {
                    Text("Hapus", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton    = {
                TextButton(onClick = { showClearDialog = false }) { Text("Batal") }
            }
        )
    }
}

// ── File Row ──────────────────────────────────────────────────────────────────

@Composable
private fun RecentFileRow(
    file    : RecentFile,
    onClick : () -> Unit,
    onDelete: () -> Unit
) {
    var showMenu    by remember { mutableStateOf(false) }
    val ext         = file.fileType
    val isTemporary = !file.isPersisted
    val iconType    = FileTypeUtil.iconKey(ext)
    val chipLabel   = FileTypeUtil.label(ext)
    val chipColor   = fileTypeColor(ext)

    Surface(
        onClick = onClick,
        color   = Color.Transparent,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ── Icon kiri ─────────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(chipColor.copy(alpha = if (isTemporary) 0.08f else 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                val iconVec = fileTypeIcon(iconType)
                Icon(
                    imageVector        = iconVec,
                    contentDescription = null,
                    modifier           = Modifier.size(20.dp),
                    tint               = if (isTemporary) chipColor.copy(alpha = 0.4f) else chipColor
                )
            }

            // ── Teks tengah ───────────────────────────────────────────────
            Column(
                modifier            = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                // Nama file
                Text(
                    text      = file.displayName,
                    style     = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    maxLines  = 1,
                    overflow  = TextOverflow.Ellipsis,
                    color     = if (isTemporary)
                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                    else
                        MaterialTheme.colorScheme.onSurface
                )
                // Metadata: badge · ukuran · baris · waktu
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Badge tipe file
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(chipColor.copy(alpha = 0.14f))
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text  = chipLabel,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                            color = chipColor,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    MetaDot()
                    Text(
                        FormatUtil.formatSize(file.sizeBytes),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (file.lineCount > 0) {
                        MetaDot()
                        Text(
                            "${file.lineCount} baris",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    MetaDot()
                    Text(
                        FormatUtil.formatRelativeTime(file.lastOpenedAt),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isTemporary)
                            MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                        else
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                    )
                }
            }

            // ── Menu kanan ────────────────────────────────────────────────
            Box {
                IconButton(
                    onClick  = { showMenu = true },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Outlined.MoreVert, null,
                        modifier = Modifier.size(16.dp),
                        tint     = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                }
                DropdownMenu(
                    expanded         = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text        = { Text("Hapus dari Riwayat") },
                        leadingIcon = { Icon(Icons.Outlined.Delete, null) },
                        onClick     = { showMenu = false; onDelete() }
                    )
                }
            }
        }
    }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

@Composable
private fun fileTypeColor(ext: String): Color {
    val scheme = MaterialTheme.colorScheme
    return when {
        ext == "json"                  -> Color(0xFF4CAF50)
        ext == "xml"                   -> Color(0xFF2196F3)
        ext == "yaml" || ext == "yml"  -> Color(0xFFFF9800)
        ext == "err" || ext.contains("err") -> Color(0xFFF44336)
        ext == "out" || ext.contains("out") -> Color(0xFF9C27B0)
        ext.endsWith(".gz")            -> Color(0xFF795548)
        else                           -> scheme.primary
    }
}

@Composable
private fun fileTypeIcon(iconType: com.aether.lv.util.FileIconType): ImageVector =
    when (iconType) {
        com.aether.lv.util.FileIconType.JSON  -> Icons.Outlined.DataObject
        com.aether.lv.util.FileIconType.XML   -> Icons.Outlined.Code
        com.aether.lv.util.FileIconType.YAML  -> Icons.Outlined.Settings
        com.aether.lv.util.FileIconType.ERROR -> Icons.Outlined.ErrorOutline
        com.aether.lv.util.FileIconType.OUT   -> Icons.Outlined.Terminal
        com.aether.lv.util.FileIconType.GZ    -> Icons.Outlined.FolderZip
        com.aether.lv.util.FileIconType.LOG   -> Icons.Outlined.Article
    }

@Composable
private fun MetaDot() {
    Text(
        "·",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)
    )
}

// ── Empty State ───────────────────────────────────────────────────────────────

@Composable
private fun EmptyState(modifier: Modifier = Modifier, onPickFile: () -> Unit) {
    Column(
        modifier            = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape    = RoundedCornerShape(28.dp),
            color    = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
            modifier = Modifier.size(88.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    Icons.Outlined.FolderOpen, null,
                    modifier = Modifier.size(44.dp),
                    tint     = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                )
            }
        }
        Spacer(Modifier.height(20.dp))
        Text(
            "Belum Ada Riwayat",
            style      = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Buka file log, txt, json, xml, gz, dan lainnya",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(28.dp))
        FilledTonalButton(onClick = onPickFile) {
            Icon(Icons.Outlined.FileOpen, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Pilih File")
        }
    }
}
