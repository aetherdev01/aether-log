package com.aether.lv.ui.screen

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.WrapText
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aether.lv.BuildConfig
import com.aether.lv.ads.AdsManager
import com.aether.lv.ads.RewardedNoAdsManager
import com.aether.lv.data.preferences.ThemePreferences
import com.aether.lv.update.UpdateDialog
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    themePrefs          : ThemePreferences,
    onBack              : () -> Unit,
    onRequestPermission : () -> Unit = {},
    onShowInterstitial  : (() -> Unit) -> Unit = { it() },
    onShowRewarded      : () -> Unit = {},
    homeVm              : HomeViewModel = viewModel()
) {
    val isDark     by themePrefs.isDarkMode.collectAsState(initial = false)
    val isDynamic  by themePrefs.isDynamicColor.collectAsState(initial = true)
    val wrapLines  by themePrefs.isWrapLines.collectAsState(initial = false)
    val showNums   by themePrefs.showLineNumbers.collectAsState(initial = true)
    val showColors by themePrefs.showLogColors.collectAsState(initial = true)
    val updateState by homeVm.updateVm.state.collectAsStateWithLifecycle()
    val rewardedState by RewardedNoAdsManager.state.collectAsStateWithLifecycle()
    val rewardedReady by AdsManager.rewardedReady.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var toggleCount by remember { mutableIntStateOf(0) }

    fun doToggle(applyPref: () -> Unit) {
        toggleCount++
        val ready = AdsManager.interstitialReady.value
        if (toggleCount % 3 == 0 && ready) {
            onShowInterstitial { applyPref() }
        } else {
            applyPref()
        }
    }

    if (updateState.showDialog) {
        UpdateDialog(
            state      = updateState,
            onDismiss  = { homeVm.updateVm.dismissDialog() },
            onDownload = { homeVm.updateVm.startDownload() },
            onInstall  = { homeVm.updateVm.install() },
            onRetry    = { homeVm.updateVm.retryDownload() }
        )
    }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Rounded.ArrowBack, "Kembali")
                        }
                    },
                    title = {
                        Text(
                            "Pengaturan",
                            fontWeight = FontWeight.SemiBold,
                            style      = MaterialTheme.typography.titleLarge,
                        )
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
                HorizontalDivider(thickness = 0.5.dp)
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier            = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding      = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {

            // ── Tema ───────────────────────────────────────────────────────
            item { SettingsGroupLabel("Tema") }
            item {
                SettingsCard {
                    val modeIcon = if (isDark) Icons.Outlined.DarkMode else Icons.Outlined.LightMode
                    val modeTint = if (isDark) Color(0xFF9FA8DA) else Color(0xFFFFA726)
                    SettingsToggleItem(
                        icon      = modeIcon,
                        iconTint  = modeTint,
                        title     = "Mode Gelap",
                        subtitle  = if (isDark) "Tema gelap aktif" else "Tema terang aktif",
                        checked   = isDark,
                        onChecked = { v -> doToggle { scope.launch { themePrefs.setDarkMode(v) } } },
                        isFirst   = true,
                        isLast    = false,
                    )
                    SettingsDivider()
                    SettingsToggleItem(
                        icon      = Icons.Outlined.AutoAwesome,
                        iconTint  = MaterialTheme.colorScheme.primary,
                        title     = "Material You",
                        subtitle  = "Warna dinamis dari wallpaper (Android 12+)",
                        checked   = isDynamic,
                        onChecked = { v -> doToggle { scope.launch { themePrefs.setDynamicColor(v) } } },
                        isFirst   = false,
                        isLast    = true,
                    )
                }
            }

            item { Spacer(Modifier.height(8.dp)) }

            // ── Viewer Log ─────────────────────────────────────────────────
            item { SettingsGroupLabel("Viewer Log") }
            item {
                SettingsCard {
                    SettingsToggleItem(
                        icon      = Icons.Outlined.ColorLens,
                        iconTint  = Color(0xFF66BB6A),
                        title     = "Warna Level Log",
                        subtitle  = "Tampilkan Warna Pada Baris ",
                        checked   = showColors,
                        onChecked = { v -> doToggle { scope.launch { themePrefs.setShowLogColors(v) } } },
                        isFirst   = true,
                        isLast    = false,
                    )
                    SettingsDivider()
                    SettingsToggleItem(
                        icon      = Icons.Outlined.Tag,
                        iconTint  = MaterialTheme.colorScheme.secondary,
                        title     = "Nomor Baris",
                        subtitle  = "Tampilkan di gutter kiri",
                        checked   = showNums,
                        onChecked = { v -> doToggle { scope.launch { themePrefs.setShowLineNumbers(v) } } },
                        isFirst   = false,
                        isLast    = false,
                    )
                    SettingsDivider()
                    SettingsToggleItem(
                        icon      = Icons.AutoMirrored.Outlined.WrapText,
                        iconTint  = MaterialTheme.colorScheme.tertiary,
                        title     = "Word Wrap",
                        subtitle  = "Bungkus baris panjang",
                        checked   = wrapLines,
                        onChecked = { v -> doToggle { scope.launch { themePrefs.setWrapLines(v) } } },
                        isFirst   = false,
                        isLast    = true,
                    )
                }
            }

            item { Spacer(Modifier.height(8.dp)) }


item { Spacer(Modifier.height(8.dp)) }

// ── No Ads Rewarded ─────────────────────────────────────────────
item { SettingsGroupLabel("No Ads") }
item {
    SettingsCard {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = "Tonton iklan rewarded untuk bebas iklan 30 menit",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )

            val statusText = when {
                rewardedState.isActive ->
                    "No Ads aktif · sisa ${formatDuration(rewardedState.remainingMillis)}"
                !rewardedState.canWatchRewarded ->
                    "Limit harian tercapai (2x/hari)"
                !rewardedReady ->
                    "Iklan rewarded belum siap"
                else ->
                    "Siap ditonton · sisa klaim hari ini: ${rewardedState.remainingClaims}"
            }

            Text(
                text = statusText,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            FilledTonalButton(
                onClick = onShowRewarded,
                enabled = rewardedReady && rewardedState.canWatchRewarded,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = when {
                        rewardedState.isActive -> "Tambah 30 Menit"
                        else -> "Tonton Iklan"
                    }
                )
            }
        }
    }
}

            // ── Sistem ─────────────────────────────────────────────────────
            item { SettingsGroupLabel("Sistem") }
            item {
                SettingsCard {
                    val hasUpdate = updateState.updateInfo?.isNewVersion == true
                    SettingsActionItem(
                        icon     = if (hasUpdate) Icons.Outlined.SystemUpdate
                                   else Icons.Outlined.Refresh,
                        iconTint = if (hasUpdate) MaterialTheme.colorScheme.primary
                                   else MaterialTheme.colorScheme.onSurfaceVariant,
                        title    = "Cek Pembaruan",
                        subtitle = when {
                            updateState.isChecking         -> "Memeriksa…"
                            hasUpdate                      -> "v${updateState.updateInfo!!.latestVersion} tersedia!"
                            updateState.updateInfo != null -> "Sudah versi terbaru · v${BuildConfig.VERSION_NAME}"
                            else                           -> "Ketuk untuk memeriksa · v${BuildConfig.VERSION_NAME}"
                        },
                        onClick  = {
                            if (AdsManager.interstitialReady.value) {
                                onShowInterstitial { homeVm.updateVm.checkForUpdate(force = true) }
                            } else {
                                homeVm.updateVm.checkForUpdate(force = true)
                            }
                        },
                        isFirst  = true,
                        isLast   = true,
                        endSlot  = {
                            AnimatedContent(
                                targetState  = updateState.isChecking to hasUpdate,
                                transitionSpec = { fadeIn() togetherWith fadeOut() },
                                label        = "updateBadge",
                            ) { (checking, update) ->
                                when {
                                    checking -> CircularProgressIndicator(
                                        modifier    = Modifier.size(18.dp),
                                        strokeWidth = 2.dp,
                                        color       = MaterialTheme.colorScheme.primary,
                                    )
                                    update -> Badge(containerColor = MaterialTheme.colorScheme.error) {
                                        Text("Baru", style = MaterialTheme.typography.labelSmall)
                                    }
                                    else -> Icon(
                                        imageVector        = Icons.Outlined.ChevronRight,
                                        contentDescription = null,
                                        modifier           = Modifier.size(18.dp),
                                        tint               = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                        }
                    )
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

// ── Group label ───────────────────────────────────────────────────────────────

@Composable
private fun SettingsGroupLabel(text: String) {
    Text(
        text       = text,
        style      = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.SemiBold,
        color      = MaterialTheme.colorScheme.primary,
        modifier   = Modifier.padding(start = 4.dp, top = 4.dp, bottom = 6.dp),
    )
}

// ── Card container ────────────────────────────────────────────────────────────

@Composable
private fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape          = RoundedCornerShape(16.dp),
        color          = MaterialTheme.colorScheme.surfaceContainerLow,
        tonalElevation = 0.dp,
        modifier       = Modifier.fillMaxWidth(),
    ) {
        Column(content = content)
    }
}

// ── Toggle item ───────────────────────────────────────────────────────────────

@Composable
private fun SettingsToggleItem(
    icon      : ImageVector,
    iconTint  : Color,
    title     : String,
    subtitle  : String,
    checked   : Boolean,
    onChecked : (Boolean) -> Unit,
    isFirst   : Boolean,
    isLast    : Boolean,
) {
    val bgColor by animateColorAsState(
        targetValue   = if (checked) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.28f)
                        else Color.Transparent,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label         = "toggleBg",
    )
    Surface(
        color    = bgColor,
        modifier = Modifier.fillMaxWidth(),
        onClick  = { onChecked(!checked) },
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    start  = 16.dp,
                    end    = 12.dp,
                    top    = if (isFirst) 14.dp else 11.dp,
                    bottom = if (isLast)  14.dp else 11.dp,
                ),
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SettingsIconBox(icon, iconTint)
            Column(
                modifier            = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(1.dp),
            ) {
                Text(title,    style = MaterialTheme.typography.bodyLarge,  fontWeight = FontWeight.Medium)
                Text(subtitle, style = MaterialTheme.typography.bodySmall,  color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(
                checked         = checked,
                onCheckedChange = onChecked,
                modifier        = Modifier.height(24.dp),
            )
        }
    }
}


private fun formatDuration(ms: Long): String {
    val totalMinutes = (ms / 60_000L).coerceAtLeast(0L)
    val hours = totalMinutes / 60
    val minutes = totalMinutes % 60
    return if (hours > 0) {
        "${hours} jam ${minutes} menit"
    } else {
        "${minutes} menit"
    }
}

// ── Action item ───────────────────────────────────────────────────────────────

@Composable
private fun SettingsActionItem(
    icon     : ImageVector,
    iconTint : Color,
    title    : String,
    subtitle : String,
    onClick  : () -> Unit,
    isFirst  : Boolean,
    isLast   : Boolean,
    endSlot  : (@Composable () -> Unit)? = null,
) {
    Surface(
        color    = Color.Transparent,
        modifier = Modifier.fillMaxWidth(),
        onClick  = onClick,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    start  = 16.dp,
                    end    = 16.dp,
                    top    = if (isFirst) 14.dp else 11.dp,
                    bottom = if (isLast)  14.dp else 11.dp,
                ),
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SettingsIconBox(icon, iconTint)
            Column(
                modifier            = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(1.dp),
            ) {
                Text(title,    style = MaterialTheme.typography.bodyLarge,  fontWeight = FontWeight.Medium)
                Text(subtitle, style = MaterialTheme.typography.bodySmall,  color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (endSlot != null) endSlot()
            else Icon(
                imageVector        = Icons.Outlined.ChevronRight,
                contentDescription = null,
                modifier           = Modifier.size(18.dp),
                tint               = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// ── Icon box ──────────────────────────────────────────────────────────────────

@Composable
private fun SettingsIconBox(icon: ImageVector, tint: Color) {
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(tint.copy(alpha = 0.14f)),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, modifier = Modifier.size(18.dp), tint = tint)
    }
}

// ── Divider ───────────────────────────────────────────────────────────────────

@Composable
private fun SettingsDivider() {
    HorizontalDivider(
        modifier  = Modifier.padding(start = 66.dp),
        thickness = 0.5.dp,
        color     = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
    )
}
