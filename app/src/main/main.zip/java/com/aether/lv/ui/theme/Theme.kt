package com.aether.lv.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// ── Static fallback – M3 Warm Amber Tonal Scheme ─────────────────────────────

private val LightColorScheme = lightColorScheme(
    primary                  = md_theme_light_primary,
    onPrimary                = md_theme_light_onPrimary,
    primaryContainer         = md_theme_light_primaryContainer,
    onPrimaryContainer       = md_theme_light_onPrimaryContainer,
    secondary                = md_theme_light_secondary,
    onSecondary              = md_theme_light_onSecondary,
    secondaryContainer       = md_theme_light_secondaryContainer,
    onSecondaryContainer     = md_theme_light_onSecondaryContainer,
    tertiary                 = md_theme_light_tertiary,
    onTertiary               = md_theme_light_onTertiary,
    tertiaryContainer        = md_theme_light_tertiaryContainer,
    onTertiaryContainer      = md_theme_light_onTertiaryContainer,
    error                    = md_theme_light_error,
    onError                  = md_theme_light_onError,
    errorContainer           = md_theme_light_errorContainer,
    onErrorContainer         = md_theme_light_onErrorContainer,
    background               = md_theme_light_background,
    onBackground             = md_theme_light_onBackground,
    surface                  = md_theme_light_surface,
    onSurface                = md_theme_light_onSurface,
    surfaceVariant           = md_theme_light_surfaceVariant,
    onSurfaceVariant         = md_theme_light_onSurfaceVariant,
    surfaceContainerLowest   = md_theme_light_surfaceContainerLowest,
    surfaceContainerLow      = md_theme_light_surfaceContainerLow,
    surfaceContainer         = md_theme_light_surfaceContainer,
    surfaceContainerHigh     = md_theme_light_surfaceContainerHigh,
    surfaceContainerHighest  = md_theme_light_surfaceContainerHighest,
    outline                  = md_theme_light_outline,
    outlineVariant           = md_theme_light_outlineVariant,
    inverseSurface           = md_theme_light_inverseSurface,
    inverseOnSurface         = md_theme_light_inverseOnSurface,
    inversePrimary           = md_theme_light_inversePrimary,
    scrim                    = md_theme_light_scrim,
)

private val DarkColorScheme = darkColorScheme(
    primary                  = md_theme_dark_primary,
    onPrimary                = md_theme_dark_onPrimary,
    primaryContainer         = md_theme_dark_primaryContainer,
    onPrimaryContainer       = md_theme_dark_onPrimaryContainer,
    secondary                = md_theme_dark_secondary,
    onSecondary              = md_theme_dark_onSecondary,
    secondaryContainer       = md_theme_dark_secondaryContainer,
    onSecondaryContainer     = md_theme_dark_onSecondaryContainer,
    tertiary                 = md_theme_dark_tertiary,
    onTertiary               = md_theme_dark_onTertiary,
    tertiaryContainer        = md_theme_dark_tertiaryContainer,
    onTertiaryContainer      = md_theme_dark_onTertiaryContainer,
    error                    = md_theme_dark_error,
    onError                  = md_theme_dark_onError,
    errorContainer           = md_theme_dark_errorContainer,
    onErrorContainer         = md_theme_dark_onErrorContainer,
    background               = md_theme_dark_background,
    onBackground             = md_theme_dark_onBackground,
    surface                  = md_theme_dark_surface,
    onSurface                = md_theme_dark_onSurface,
    surfaceVariant           = md_theme_dark_surfaceVariant,
    onSurfaceVariant         = md_theme_dark_onSurfaceVariant,
    surfaceContainerLowest   = md_theme_dark_surfaceContainerLowest,
    surfaceContainerLow      = md_theme_dark_surfaceContainerLow,
    surfaceContainer         = md_theme_dark_surfaceContainer,
    surfaceContainerHigh     = md_theme_dark_surfaceContainerHigh,
    surfaceContainerHighest  = md_theme_dark_surfaceContainerHighest,
    outline                  = md_theme_dark_outline,
    outlineVariant           = md_theme_dark_outlineVariant,
    inverseSurface           = md_theme_dark_inverseSurface,
    inverseOnSurface         = md_theme_dark_inverseOnSurface,
    inversePrimary           = md_theme_dark_inversePrimary,
    scrim                    = md_theme_dark_scrim,
)

// ── Theme entry point ─────────────────────────────────────────────────────────

@Composable
fun LogLogTheme(
    darkTheme    : Boolean = true,
    dynamicColor : Boolean = true,
    content      : @Composable () -> Unit,
) {
    val colorScheme = when {
        // Android 12+ → Material You dari wallpaper
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context)
            else           dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else      -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view)
                .isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography  = Typography,
        content     = content,
    )
}
